AVR-nRF24L01+
=============

A library for using the nRF24L01+ with AVR chips like the ATmega328, written in C.

You can find the equivalent Arduino library here: https://github.com/antoineleclair/arduino-nrf24l01.
