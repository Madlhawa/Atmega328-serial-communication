#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdio.h>

void init_lcd(void);
void moveto(unsigned char, unsigned char);
void stringout(char *);
void writecommand(unsigned char);
void writedata(unsigned char);
void writenibble(unsigned char);

unsigned char temp = 0x00;

/* UART SERIAL DEFINES */
#define BAUD 9600
#define MYUBRR F_CPU/16/BAUD-1

#define FOSC 16000000 // Clock frequency

/* SETUP UART */
void USART_Init( unsigned int ubrr);






/* Simple methods to make UART read and transmit more readble - Extremely unnecessary*/
void USART_Transmit( unsigned char data );

unsigned char USART_Receive( void );

void SendString(char *StringPtr);



 char input[20];
 int counter;
  
void timer0_init()
{
    // set up timer with no prescaling
    //TCCR0 |= (1 << CS00);
  
    // initialize counter
   // TCNT0 = 0;
}
 void init_timer1(unsigned short m)
 {
	 TCCR1B |= (0b00001101);
	 TIMSK1 |= (0X02);
	 OCR1A = m;
 
 }
  
/* SETUP UART */
void USART_Init( unsigned int ubrr)
{
   /*Set baud rate */
  
  /*Enable receiver and transmitter */
  
   
   /* Set frame format */
   UBRR0 = MYUBRR; 
	UCSR0B |= (1 << TXEN0 | 1 << RXEN0); // Enable RX and TX
	UCSR0C = (3 << UCSZ00); 
}




/* Simple methods to make UART read and transmit more readble - Extremely unnecessary*/
void USART_Transmit( unsigned char data )
{
		// Wait for transmitter data register empty
		while ((UCSR0A & (1<<UDRE0)) == 0) {}
		UDR0 = data;
}


unsigned char USART_Receive( void )
{
   // Wait for receive complete flag to go high
		while ( !(UCSR0A & (1 << RXC0)) ) {}
		//ReceiveString();
		//stringout("UDR0");
		return UDR0;

}

void SendString(char *StringPtr)
{
	
	while(*StringPtr != 0x00)
	{  
	USART_Transmit(*StringPtr);    
	StringPtr++;
	}        

}

//void ReceiveString()
//{ 
//		stringout(USART_Receive());    
	        

//}

	
  
  
int main(void)
{
	init_lcd();
	_delay_ms(15);
	writecommand(0x01); // clear lcd
	
	

    // initialize timer
    timer0_init();
    USART_Init(MYUBRR);	
	init_timer1(20000);
    // loop forever
	sei();
    while(1)
    {
		SendString(" I AM ");
		_delay_ms(1000);
        // check if the timer count reaches 191
      // if (TCNT0 >= 191)
      // {
      //     SendString("abc!");
		//    _delay_ms(1000);
      //    TCNT0 = 0;            // reset counter
      //  }
    }
}

ISR(TIMER1_COMPA_vect){
		
		//SendString("CSN ");
}


/// LCD Part

/*
  init_lcd - Configure the I/O ports and send the initialization commands
*/
void init_lcd()
{
    DDRD |=0xf0;                 // Set the DDR register bits for ports B and D
	DDRB |=0x03;
	
    _delay_ms(15);              // Delay at least 15ms

     writecommand(0x03);                  // Use writenibble to send 0011
    _delay_ms(4);               // Delay at least 4msec

      writecommand(0x03);                 // Use writenibble to send 0011
    _delay_us(100);             // Delay at least 100usec

   writecommand(0x03);                   // Use writenibble to send 0011, no delay needed

    writecommand(0x02);                  // Use writenibble to send 0010
    _delay_ms(2);               // Delay at least 2ms
    
    writecommand(0x28);         // Function Set: 4-bit interface, 2 lines

    writecommand(0x0f);         // Display and cursor on

}	

/*
  moveto - Move the cursor to the row (0 or 1) and column (0 to 15) specified
*/
void moveto(unsigned char row, unsigned char col)
{
    if(row==0){
		
		writecommand(0x80+col);
	}
	if(row==1){
		
		writecommand(0xc0+col);
	}
}

/*
  stringout - Write the string pointed to by "str" at the current position
*/
void stringout(char *str)
{
    for (; *str != '\0'; str++){
   writedata(*str);
	}
}

/*
  writecommand - Send the 8-bit byte "cmd" to the LCD command register
*/
void writecommand(unsigned char cmd)
{
	PORTB&=~(0x01);
	temp=cmd&0xF0;
	writenibble(temp);
	temp=cmd&0x0F;
	temp=temp<<4;
	writenibble(temp);
	_delay_ms(3);

}

/*
  writedata - Send the 8-bit byte "dat" to the LCD data register
*/
void writedata(unsigned char data)
{
	PORTB |= 0x01;
	temp=data&0xF0;
	writenibble(temp);
	temp=data&0x0F;
	temp=temp<<4;
	writenibble(temp);
	_delay_ms(3);

}

/*
  writenibble - Send four bits of the byte "lcdbits" to the LCD
*/
void writenibble(unsigned char lcdbits)
{
	
	
	PORTD = lcdbits;
	
	PORTB &= ~(0x02);
	PORTB |= 0x02;
	//PORTD &= ~MASKBITS; //0X00
	//PORTD |= (lcdbits & MASKBITS);
	
	PORTB &= ~(0x02);
	//PORTB |= 0X02;
	//PORTD &= ~MASKBITS;
	//PORTD |= (lcdbits << 4 & MASKBITS);
	
	
}


