#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>


/* UART SERIAL DEFINES */
#define BAUD 9600
#define MYUBRR F_CPU/16/BAUD-1

#define FOSC 16000000 // Clock frequency

/* SETUP UART */
void USART_Init( unsigned int ubrr);






/* Simple methods to make UART read and transmit more readble - Extremely unnecessary*/
void USART_Transmit( unsigned char data );

unsigned char USART_Receive( void );

void SendString(char *StringPtr);



 char input[20];
 int counter;
  
void timer0_init()
{
    // set up timer with no prescaling
    //TCCR0 |= (1 << CS00);
  
    // initialize counter
   // TCNT0 = 0;
}
 void init_timer1(unsigned short m)
 {
	 TCCR1B |= (0b00001101);
	 TIMSK1 |= (0X02);
	 OCR1A = m;
 
 }
  
/* SETUP UART */
void USART_Init( unsigned int ubrr)
{
   /*Set baud rate */
  
  /*Enable receiver and transmitter */
  
   
   /* Set frame format */
   UBRR0 = MYUBRR; 
	UCSR0B |= (1 << TXEN0 | 1 << RXEN0); // Enable RX and TX
	UCSR0C = (3 << UCSZ00); 
}




/* Simple methods to make UART read and transmit more readble - Extremely unnecessary*/
void USART_Transmit( unsigned char data )
{
		// Wait for transmitter data register empty
		while ((UCSR0A & (1<<UDRE0)) == 0) {}
		UDR0 = data;
}


unsigned char USART_Receive( void )
{
   // Wait for receive complete flag to go high
		while ( !(UCSR0A & (1 << RXC0)) ) {}
		return UDR0;

}

void SendString(char *StringPtr)
{
	
	while(*StringPtr != 0x00)
	{  
	USART_Transmit(*StringPtr);    
	StringPtr++;
	}        

}


	
  
  
int main(void)
{
  
	
	

    // initialize timer
    timer0_init();
    USART_Init(MYUBRR);	
	init_timer1(20000);
    // loop forever
	sei();
    while(1)
    {
		SendString(" I AM ");
		_delay_ms(1000);
        // check if the timer count reaches 191
      // if (TCNT0 >= 191)
      // {
      //     SendString("abc!");
		//    _delay_ms(1000);
      //    TCNT0 = 0;            // reset counter
      //  }
    }
}

ISR(TIMER1_COMPA_vect){
		
		SendString("CSN ");
}
	



